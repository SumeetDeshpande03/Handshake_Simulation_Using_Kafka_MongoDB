const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const JobPostSchema = new Schema({  
    companyName: String,
    title: {
        type: String,
        required: true
    } ,
    postingDate: String,
    deadline: String,
    location: String,
    salary: String,
    jobDescription: {
        type: String,
        required: true
    },
    category: String,
    students: [{    
        studentId: Schema.Types.ObjectId,
        name: String,
        collegeName: String,
        major: String,
        cgpa: String, 
    }]
})

const JobPost = mongoose.model('jobpost', JobPostSchema);

module.exports = JobPost;